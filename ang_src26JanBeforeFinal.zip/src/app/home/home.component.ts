import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { DataService } from '../data.service';
import { isNull, isNullOrUndefined } from 'util';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private router: Router, private service:DataService) {
    
   }

    cats:any
    names:any
    products:any
    category:any
    checkList= []
    count = 0;
    test = []


    

  ngOnInit()
   {
     let cat = this.service.getAllCategories();
     cat.subscribe((result)=>{
       this.cats = result;
       console.log(this.cats);
     })
     let test = this.service.getAllProducts();
     test.subscribe((results)=>{
       this.names = results;
       console.log(this.names)
     })
    
     //console.log(sessionStorage.getItem("count"))

  }
   
  onLogOut()
  {
    this.router.navigate(['/logout']);
  }

  Category()
  {
    if(this.category==null)
    {
      alert("choose a category");
    }
       
    else
    {
    //   this.count = parseInt((sessionStorage.getItem("count")));
    // sessionStorage.setItem(this.count.toString(), JSON.stringify(this.checkList))
    // console.log(sessionStorage.getItem(this.count.toString()))
    // this.count++;
    // sessionStorage.setItem("count", this.count.toString())

      console.log(this.category)
      sessionStorage.setItem("cat", this.category);
      let id = sessionStorage.getItem("cat");
      console.log(id);
      let prod = this.service.getCatProducts(this.category);
      prod.subscribe((result)=>{
        console.log(result);
        this.names = result;
        
      })
    }
  }

  cart(name)
  {
    //debugger;
    console.log(name)
    //this.checkList.push(name);
    


    this.count = parseInt((sessionStorage.getItem("count")));
    sessionStorage.setItem(this.count.toString(), JSON.stringify(name))
    //console.log(sessionStorage.getItem(this.count.toString()))
    this.count++;
    sessionStorage.setItem("count", this.count.toString())



    // let cart = JSON.stringify(this.checkList);
    // sessionStorage.setItem("cart", cart);
    // console.log(sessionStorage.getItem("cart"))
    alert("product added to cart")
    
  }
}
