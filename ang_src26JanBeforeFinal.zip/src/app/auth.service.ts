
import { Injectable } from '@angular/core';

import { CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot, Router } from '@angular/router';
import { DataService } from './data.service';
import { isNull } from 'util';
@Injectable({
  providedIn: 'root'
})
export class AuthService implements CanActivate {

  emp:any;
  count=0
  constructor(private router:Router,private service:DataService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
  {
     var v  = this.IsLoggedIn()


   if(v==true)
   {
     console.log("User Has Logged in");
     return true;
   }
   else
   {
    console.log("User has not logged");
     this.router.navigate(['']);
     return false;  
   }
  }

  IsLoggedIn()
  {
    
    if(window.sessionStorage.getItem("login_status")!=null 
        && 
       window.sessionStorage.getItem("login_status")=="1")
    {
      return true;
    }
    else{
      return false;
    }
  }

  CheckCredentialsWithDB(userDetails)
  {
    
    //Call Some  Service using Post Method
    //to check credentials with DB
    let observableResult= this.service.validateUser(userDetails);
    observableResult.subscribe((result)=>{
      this.emp=result
      console.log(this.emp)
      if(!isNull(this.emp))
      {   
         
        
        
        if(this.emp.type=="ADMIN" )
        {
          
         sessionStorage['login_status'] = '1';
         localStorage.setItem('user',JSON.stringify(this.emp));
         console.log(JSON.parse(localStorage.getItem('user')))
         localStorage.setItem('flag','true');
         
         this.router.navigate(['/admin']);
        }
        else if(this.emp.type=="CUSTOMER")
        {
   
            sessionStorage['login_status'] = '1';
            localStorage.setItem('user',JSON.stringify(this.emp));
            console.log(JSON.parse(localStorage.getItem('user')))
            
            sessionStorage.setItem("count", this.count.toString())

            localStorage.setItem('flag','true');
           
         
            this.router.navigate(['/home']);
        }
        
        else
        {
           alert("invalid login");
           this.router.navigate(['']);
        }
       }
       else
       {
         
         return "invalid";
       }
     
      
    })
  }

  Logout()
  {
    window.sessionStorage.setItem("login_status", "0");
    this.router.navigate(['']);
  }
}