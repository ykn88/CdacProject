package com.app.pojos;

public enum payType {
   COD, CARD
}
