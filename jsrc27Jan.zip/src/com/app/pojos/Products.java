	package com.app.pojos;

import javax.persistence.*;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "products")
@JsonIgnoreProperties(value = {"prodImage", "odetails"})
public class Products {

	private Integer prodId;
	private String prodName, prodDesc;
	private int prodQuantity;
	private float price;
	private byte[] prodImage;
	private Categories category;
	private OrderDetails odetails;
	
	public Products() {
		// TODO Auto-generated constructor stub
	}
	
	


   
	
	public Products(String prodName, String prodDesc, int prodQuantity, float price) {
		super();
		this.prodName = prodName;
		this.prodDesc = prodDesc;
		this.prodQuantity = prodQuantity;
		this.price = price;
	}






	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "product_id")
	public Integer getProdId() {
		return prodId;
	}



	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}



	@Column(name = "product_name", length = 30)
	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	@Column(name = "product_description")
	public String getProdDesc() {
		return prodDesc;
	}

	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}

	
	@Column(name = "product_quantity")
	public int getProdQuantity() {
		return prodQuantity;
	}

	public void setProdQuantity(int prodQuantity) {
		this.prodQuantity = prodQuantity;
	}

	@Column(name = "product_price")
	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Lob
	public byte[] getProdImage() {
		return prodImage;
	}

	public void setProdImage(byte[] prodImage) {
		this.prodImage = prodImage;
	}


   


    @ManyToOne
    @JoinColumn(name = "category_id")
    @JsonBackReference
	public Categories getCategory() {
		return category;
	}






	public void setCategory(Categories category) {
		this.category = category;
	}


	@OneToOne(cascade = CascadeType.ALL, mappedBy = "product", orphanRemoval = true)
	public OrderDetails getOdetails() {
		return odetails;
	}


	public void setOdetails(OrderDetails odetails) {
		this.odetails = odetails;
	}


	public void addOrderDetails(OrderDetails od)
	{
		setOdetails(od);
		od.setProduct(this);
	}
	


	@Override
	public String toString() {
		return "Products [prodId=" + prodId + ", prodName=" + prodName + ", prodDesc=" + prodDesc + ", prodQuantity="
				+ prodQuantity + ", price=" + price + "]";
	}
	
	
	
	
}
