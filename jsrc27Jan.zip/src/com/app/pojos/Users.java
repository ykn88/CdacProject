package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "users") 
@JsonIgnoreProperties(value = {"orders"})
public class Users
{
  private Integer user_id;
  private String fname, lname, email, password, address, phone;
  private userTypes type;
  private List<Orders> orders = new ArrayList<>();
  
  public Users() {
	
 }






public Users(String fname, String lname, String email, String password, String address, String phone, userTypes type) {
	super();
	this.fname = fname;
	this.lname = lname;
	this.email = email;
	this.password = password;
	this.address = address;
	this.phone = phone;
	this.type = type;
}




public Users(Integer user_id) {
	super();
	this.user_id = user_id;
}






@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
public Integer getUser_id() {
	return user_id;
}

public void setUser_id(Integer user_id) {
	this.user_id = user_id;
}

@Column(name = "first_name", length = 20)
public String getFname() {
	return fname;
}

public void setFname(String fname) {
	this.fname = fname;
}

@Column(name = "last_name", length = 20)
public String getLname() {
	return lname;
}

public void setLname(String lname) {
	this.lname = lname;
}

@Column(length = 30, unique = true)
public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

@Column(length = 30)
public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

@Column(length = 50)
public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

@Column(length = 30)
public String getPhone() {
	return phone;
}


public void setPhone(String phone) {
	this.phone = phone;
}

@Enumerated(EnumType.STRING)
@Column(name = "user_type", length = 10)
public userTypes getType() {
	return type;
}


public void setType(userTypes type) {
	this.type = type;
}





@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
@JsonIgnore
public List<Orders> getOrders() {
	return orders;
}






public void setOrders(List<Orders> orders) {
	this.orders = orders;
}


public void addOrder(Orders o)
{
	orders.add(o);
	o.setUser(this);
}
public void removeOrder(Orders o)
{
	orders.remove(o);
	o.setUser(null);
}






@Override
public String toString() {
	return "Users [user_id=" + user_id + ", fname=" + fname + ", lname=" + lname + ", email=" + email + ", password="
			+ password + ", address=" + address + ", phone=" + phone + ", type=" + type + "]";
}
  
  
	
}
