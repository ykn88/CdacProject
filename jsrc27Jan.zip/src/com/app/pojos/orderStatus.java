package com.app.pojos;

public enum orderStatus {
  DELIVERED, SHIPPED, CANCELLED, OUT_FOR_DELIVERY
}
