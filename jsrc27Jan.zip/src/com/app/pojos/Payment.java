package com.app.pojos;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "payment")
public class Payment
{
	private Integer payId;
	private float amount;
	private Date payDate;
	private payType type;
	private Orders orders;
	
	public Payment() {
		// TODO Auto-generated constructor stub
	}
	
	

	public Payment(Integer payId, float amount, Date payDate, payType type) {
		super();
		this.payId = payId;
		this.amount = amount;
		this.payDate = payDate;
		this.type = type;
	}


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getPayId() {
		return payId;
	}



	public void setPayId(Integer payId) {
		this.payId = payId;
	}


	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "pay_date")
	public Date getPayDate() {
		return payDate;
	}

	public void setPayDate(Date payDate) {
		this.payDate = payDate;
	}

	@Enumerated(EnumType.STRING)
	public payType getType() {
		return type;
	}

	public void setType(payType type) {
		this.type = type;
	}
	
	
    @OneToOne
    @JoinColumn(name = "order_id")
	public Orders getOrders() {
		return orders;
	}



	public void setOrders(Orders orders) {
		this.orders = orders;
	}



	@Override
	public String toString() {
		return "Payment [payId=" + payId + ", amount=" + amount + ", payDate=" + payDate + ", type=" + type + "]";
	}
	
	
	
}
