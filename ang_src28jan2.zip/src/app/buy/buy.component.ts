import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';
import {UUID} from  'angular2-uuid'


@Component({
  selector: 'app-buy',
  templateUrl: './buy.component.html',
  styleUrls: ['./buy.component.css']
})
export class BuyComponent implements OnInit {

  constructor(private router: Router, private service: DataService) { }
  a:any
  user:any
  payment:any
  type:any
  result:any
  today:any
  order:any
  number:Number
  uuid:any
  test:any
  id : any
  amount:any
  details:any
  detail:any
  paytest:any

  ngOnInit() {

    this.number = Math.round(Math.random()*100000)%99929  


       this.user = JSON.parse(localStorage.getItem("user"))
       console.log(this.user)  

       this.today = new Date();
       var dd = String(this.today.getDate()).padStart(2, '0');
       var mm = String(this.today.getMonth() + 1).padStart(2, '0'); //January is 0!
         var yyyy = this.today.getFullYear();

           this.today = yyyy + '-' + mm + '-' + dd;
           console.log(this.today)

           this.test  = {"orderNumber":this.number}
           console.log(this.test)
           this.amount = parseInt(sessionStorage.getItem('payment'))
           console.log(this.amount)
           this.payment = {"amount":this.amount, "payDate":this.today, "type":"COD"}
           console.log(this.payment)
                    
       
  }

   orderDetails()
  {
      this.detail = {"quantity":1}

      this.details = JSON.parse(sessionStorage.getItem('order'))
      console.log(this.details)
      for (let index = 0; index < this.details.length; index++) {
            console.log(this.order.order_id)
            console.log(this.detail)
            console.log(this.details[index].prodId)    
           this.service.addOrderDetails(this.order.order_id ,this.details[index].prodId, this.detail).subscribe((result)=>{
             console.log(result);
           }) 


      }

     // sessionStorage.removeItem("count")

      this.router.navigate(['/thanks'])
  }

  async payOut()
  {
        
  this.order = await this.service.order(this.a).toPromise()

  console.log(this.order)

  await this.service.makePayment(this.payment, this.order.order_id).toPromise()
 

  this.orderDetails()

  }  
  

  placeOrder()
  {
    this.a = { "address":this.user.address,"shippedDate":this.today,"orderDate":this.today, "orderNumber":this.number}
    console.log(this.a)
   
   this.service.addOrder(this.user.user_id, this.a).subscribe((abc)=>{
     alert("Order placed successfully") 
     this.payOut()

   })



  }
}
