import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private router: Router, private service: DataService) { }

  cartList = [];

  total = 0
  number = 0
  check=[]
  ngOnInit() {

    //  debugger  
    for (var i = 0; i < parseInt(sessionStorage.getItem("count")); i++) {
      this.cartList[i] = JSON.parse(sessionStorage.getItem(i.toString()));
      //console.log(this.cartList)
    }
    for (var i = 0; i < this.cartList.length; i++) {
      this.total = this.total + (this.cartList[i].price);
    }
    console.log(this.total)
    sessionStorage.setItem('order', JSON.stringify(this.cartList))

    let total = JSON.stringify(this.total)
    sessionStorage.setItem('payment', total)
    console.log(JSON.parse(sessionStorage.getItem('payment')))


  }

  remove(list) {
    this.total = 0;
    let p = this.cartList.indexOf(list);
    this.cartList.splice(p, 1);
    for (var i = 0; i < this.cartList.length; i++) {
      this.total = this.total + this.cartList[i].price;
    }
    console.log(this.total)
    let v = JSON.stringify(this.cartList)
    sessionStorage.setItem('order', v)
    let total = JSON.stringify(this.total)
    sessionStorage.setItem('payment', total)

    console.log(JSON.parse(sessionStorage.getItem('payment')))

    console.log(JSON.parse(sessionStorage.getItem('order')))

  }

  payment() {
    console.log(JSON.parse(sessionStorage.getItem("order")))
    console.log(JSON.parse(sessionStorage.getItem('payment')))

    this.router.navigate(['/buy'])
  }


}
