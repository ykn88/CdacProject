import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';
import * as jspdf from 'jspdf'

@Component({
  selector: 'app-odetails',
  templateUrl: './odetails.component.html',
  styleUrls: ['./odetails.component.css']
})
export class OdetailsComponent implements OnInit {

  id:Number
  values:any

 

  @ViewChild('content',{static:false}) content: ElementRef;

  constructor(private router: Router, 
              private service: DataService) { }

   payment = 0           

  async ngOnInit() 
  {
     
     this.id = parseInt(localStorage.getItem('id'))
     console.log(this.id)
 
     this.values = await this.service.getOrderDetails(this.id).toPromise()

     console.log(this.values)


     for (let index = 0; index < this.values.length; index++) {
       this.payment = this.values[index].product.price + this.payment;
       
     }

     console.log(this.payment)
      

  }

  pdf()
  {
    let doc = new jspdf()

    let handler = {
      '#editor': function(element, renderer){
        return true;
      }
    }

    let content = this.content.nativeElement;

    doc.fromHTML(content.innerHTML, 15, 15, {
      'width':190,
      'elementHandlers': handler
    })

    doc.save('invoice.pdf')
  }

}
