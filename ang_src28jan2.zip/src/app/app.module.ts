import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, NgModel, NgForm } from '@angular/forms';
import {  HttpClientModule } from '@angular/common/http';
import { RouterModule,Routes } from '@angular/router';
//import {ToastrModule} from 'ngx-toastr'


import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { RegisterComponent } from './register/register.component';
import { CategoriesComponent } from './categories/categories.component';
import { BuyComponent } from './buy/buy.component';
import { ThanksComponent } from './thanks/thanks.component';
import {ListusersComponent} from './listusers/listusers.component';
import { NewproductComponent } from './newproduct/newproduct.component'
import { AuthService } from './auth.service';
import { LogoutComponent } from './logout/logout.component';
import { CartComponent } from './cart/cart.component';
import { AddAdminComponent } from './add-admin/add-admin.component';
import { MyorderComponent } from './myorder/myorder.component';
import { OdetailsComponent } from './odetails/odetails.component';
import { EditComponent } from './edit/edit.component';
import { SampleModule } from 'angular-pdf-generator';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    AdminComponent,
    RegisterComponent,
    CategoriesComponent,
    BuyComponent,
    ThanksComponent,
    ListusersComponent,
    NewproductComponent,
    LogoutComponent,
    CartComponent,
    AddAdminComponent,
    MyorderComponent,
    OdetailsComponent,
    EditComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path:'', component:LoginComponent},
      {path:'home', component:HomeComponent, canActivate:[AuthService]},
      {path:'admin', component:AdminComponent, canActivate:[AuthService]},
      {path:'register', component:RegisterComponent},
      {path:'categories', component:CategoriesComponent, canActivate:[AuthService]},
      {path:'buy', component:BuyComponent, canActivate:[AuthService]},
      {path:'thanks', component:ThanksComponent},
      {path:'listusers', component:ListusersComponent, canActivate:[AuthService]},
      {path:'addproduct', component:NewproductComponent, canActivate:[AuthService]},
      {path: 'logout', component:LogoutComponent},
      {path:'cart', component:CartComponent, canActivate:[AuthService]},
      {path:'addAdmin', component:AddAdminComponent, canActivate:[AuthService]},
      {path:'myorders', component:MyorderComponent, canActivate:[AuthService]},
      {path:'odetails', component:OdetailsComponent, canActivate:[AuthService]},
      {path:'edit', component:EditComponent, canActivate:[AuthService]}
    ])
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
