package com.app.convenience;

import com.app.pojos.*;

public class CatProd {
   private Products prod;
   private Categories cat;
public CatProd(Products prod, Categories cat) {
	super();
	this.prod = prod;
	this.cat = cat;
}

public CatProd() {
	// TODO Auto-generated constructor stub
}
public Products getProd() {
	return prod;
}
public void setProd(Products prod) {
	this.prod = prod;
}
public Categories getCat() {
	return cat;
}
public void setCat(Categories cat) {
	this.cat = cat;
}
   
   
}
