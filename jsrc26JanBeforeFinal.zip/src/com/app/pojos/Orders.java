package com.app.pojos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "orders")
@JsonIgnoreProperties(value = {"user", "orderDetails"})
public class Orders
{
	private Integer order_id;
	private String address;
	private Date shippedDate;
	private Date orderDate;
	private Users user;
	private List<OrderDetails> orderDetails = new ArrayList<OrderDetails>();
	private Payment payment;
	private Integer orderNumber;
	
	public Orders() {
		// TODO Auto-generated constructor stub
	}

	
	
	
	



	



	public Orders(String address, Date shippedDate, Date orderDate) {
		super();
		this.address = address;
		this.shippedDate = shippedDate;
		this.orderDate = orderDate;
	}












	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getOrder_id() {
		return order_id;
	}

	public void setOrder_id(Integer order_id) {
		this.order_id = order_id;
	}

	@Column(name = "shipping_address", length = 50)
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "shipping_date")
	public Date getShippedDate() {
		return shippedDate;
	}

	public void setShippedDate(Date shippedDate) {
		this.shippedDate = shippedDate;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "order_date")
	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	
	
    @ManyToOne
    @JoinColumn(name = "user_id")
	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}
	
	
	



	




	public int getOrderNumber() {
		return orderNumber;
	}








	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}








	@OneToMany(mappedBy = "orders", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	public List<OrderDetails> getOrderDetails() {
		return orderDetails;
	}
    
    
    @OneToOne(cascade = CascadeType.ALL,  mappedBy = "orders", orphanRemoval = true)
	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	public void setOrderDetails(List<OrderDetails> orderDetails) {
		this.orderDetails = orderDetails;
	}
	
	public void addOrderDetails(OrderDetails od)
	{
		orderDetails.add(od);
		od.setOrders(this);
	}
	public void removeOrderDetails(OrderDetails od)
	{
		orderDetails.remove(od);
		od.setOrders(null);
	}
	
	public void addPaymentDetails(Payment p)
	{
		setPayment(p);
		p.setOrders(this);
	}
	

	@Override
	public String toString() {
		return "Orders [order_id=" + order_id + ", address=" + address + ", shippedDate=" + shippedDate + ", orderDate="
				+ orderDate + "]";
	}
	
	
}
