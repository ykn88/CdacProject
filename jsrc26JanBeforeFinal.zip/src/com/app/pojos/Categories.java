package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "categories")
public class Categories
{
       private Integer id;
       private String name;
       private String details;
       private List<Products> products = new ArrayList<>();
       
       public Categories() {
		// TODO Auto-generated constructor stub
	}

	public Categories(String name, String details) {
		super();
		this.name = name;
		this.details = details;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "category_id")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "category_name", length = 20)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}
	
	
    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JsonManagedReference
	public List<Products> getProducts() {
		return products;
	}

	public void setProducts(List<Products> products) {
		this.products = products;
	}
				
	public void addProduct(Products p)
	{
		products.add(p);
		p.setCategory(this);;
	}
	public void removeProduct(Products p)
	{
		products.remove(p);
		p.setCategory(null);
	}

	@Override
	public String toString() {
		return "Categories [id=" + id + ", name=" + name + ", details=" + details + "]";
	}
       
       
}
