package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IUserDao;
import com.app.pojos.Categories;
import com.app.pojos.OrderDetails;
import com.app.pojos.Orders;
import com.app.pojos.Payment;
import com.app.pojos.Products;
import com.app.pojos.Users;


@Service
@Transactional
public class UserServiceImpl implements IUserService {

	public UserServiceImpl() {
		System.out.println(org.hibernate.Version.getVersionString());
	}

	@Autowired
	private IUserDao dao;
	
	@Override
	public List<Categories> getAllCategories() {
		
		return dao.getAllCategories();
	}
	
	@Override
	public Users performValidate(String email, String password) {
		
		return dao.performValidate(email, password);
	}

	@Override
	public List<Categories> getAllProducts(int id) {
		// TODO Auto-generated method stub
		return dao.getAllProducts(id);
	}

	@Override
	public List<Products> productList() {
		return dao.productList();
	}

	@Override
	public List<Products> selectiveProductList(int id) {
		return dao.selectiveProductList(id);
	}
	
	public void addUser(Users u)
	{
		dao.addUser(u);
	}

	@Override
	public List<Orders> getAllUserOrders() {
            
		return dao.getAllUserOrders();
	}

	@Override
	public List<OrderDetails> getOrderDetails(int id) {
		// TODO Auto-generated method stub
		return dao.getOrderDetails(id);
	}

	@Override
	public List<Products> getProductsByName(String name) {
		// TODO Auto-generated method stub
		return dao.getProductsByName(name);
	}

	@Override
	public Users getUsersById(int id) {
		return dao.getUsersById(id);
	}

	@Override
	public void deleteUser(int id) {
		// TODO Auto-generated method stub
	     dao.deleteUser(id);
	}

	@Override
	public Boolean setUserDetails(Users u) {
		// TODO Auto-generated method stub
		return dao.setUserDetails(u);
	}

	@Override
	public List<Orders> myOrders(Users u) {
		// TODO Auto-generated method stub
		return dao.getAllUserOrders();
	}

	@Override
	public void makePayment(Payment p, Orders o) {
		// TODO Auto-generated method stub
		dao.makePayment(p, o);
	}

	@Override
	public Orders getOrderById(int id) {
		// TODO Auto-generated method stub
		return dao.getOrderById(id);
	}

	@Override
	public Products getProductById(int id) {
		// TODO Auto-generated method stub
		return dao.getProductById(id);
	}

	@Override
	public void addOrderDetails(OrderDetails od, Orders o, Products p) {
		// TODO Auto-generated method stub
		dao.addOrderDetails(od, o, p);
	}

	@Override
	public void addOrders(Orders o, int userId) {
         dao.addOrder(o, userId);		
	}

	

	@Override
	public Orders getOrder(int id) {
		// TODO Auto-generated method stub
		return dao.getOrder(id);
	}

	@Override
	public Orders order(int ordernumber) {
		return dao.order(ordernumber);
	}

}
