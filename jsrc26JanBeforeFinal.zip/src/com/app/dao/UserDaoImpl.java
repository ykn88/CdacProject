package com.app.dao;

import java.sql.Date;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Categories;
import com.app.pojos.OrderDetails;
import com.app.pojos.Orders;
import com.app.pojos.Payment;
import com.app.pojos.Products;
import com.app.pojos.Users;


@Repository
public class UserDaoImpl implements IUserDao {

	

	@Autowired
	private SessionFactory sf;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Categories> getAllCategories() {
		String jpql = "select c from Categories c";
		return sf.getCurrentSession().createQuery(jpql).getResultList();
	}
	
	@Override
	public Users performValidate(String email, String password) {
		String jpql = "select u from Users u where u.email=:email and u.password=:password";
		Users user = sf.getCurrentSession().createQuery(jpql, Users.class).setParameter("email", email)
				                .setParameter("password", password).getSingleResult();
		if(user != null)
			return user;
		return null;
	}
	
	public List<Categories> getAllProducts(int id) {
		String jpql = "select distinct p from Categories p join fetch p.products where p.id=:id ";
		return sf.getCurrentSession().createQuery(jpql, Categories.class).setParameter("id", id).getResultList();
	}

	@Override
	public List<Products> productList() {
		String jpql = "select pr from Products pr";
		return sf.getCurrentSession().createQuery(jpql, Products.class).getResultList();
	}

	@Override
	public List<Products> selectiveProductList(int id) {
		System.out.println("In sysysy");
		  String jpql = "select p from Products p where category_id=:id";
		  
		return sf.getCurrentSession().createQuery(jpql, Products.class).setParameter("id", id).getResultList();
	}
	
	@Override
	public void addUser(Users user) 
	{
		sf.getCurrentSession().persist(user);
	}

	@Override
	public List<Orders> getAllUserOrders() {
        String jpql = "select o from Orders o";
        return sf.getCurrentSession().createQuery(jpql, Orders.class).getResultList();
		
	}

	@Override
	public List<OrderDetails> getOrderDetails(int id) {
       String jpql = "select od from OrderDetails od where order_id = :id";
      
		return sf.getCurrentSession().createQuery(jpql, OrderDetails.class).setParameter("id", id).getResultList();
	}

	@Override
	public List<Products> getProductsByName(String name) {
		String jpql = "select p from Products p where p.prodName = :name";
		return sf.getCurrentSession().createQuery(jpql, Products.class).setParameter("name", name).getResultList();
		
	}
	
	@Override
	public Users getUsersById(int id) 
	{
		String jpql="select u from Users u where u.user_id=:id";
		return sf.getCurrentSession().createQuery(jpql,Users.class).setParameter("id", id).getSingleResult();
	}
	
	@Override
	public void deleteUser(int id) 
	{
		Users u =sf.getCurrentSession().get(Users.class, id);
		sf.getCurrentSession().delete(u);
		
	}
	
	@Override
	public Boolean setUserDetails(Users u) {
		try
		{
			String email = u.getEmail();
			String jpql = "select c from Customer c where c.email  = :email";
			Users currentUser = sf.getCurrentSession().createQuery(jpql, Users.class).setParameter("email", email).getSingleResult();
			currentUser.setFname(u.getFname());
			currentUser.setPhone(u.getPhone());
			currentUser.setAddress(u.getAddress());
			return true;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Orders> myOrders(Users u)
	{
		System.out.println("In my Orders");
		String jpql="select o from Orders o where o.user=:uid";
		return sf.getCurrentSession().createQuery(jpql, Orders.class).setParameter("uid", u).getResultList();
	}
	
	@Override
	public void makePayment(Payment p,Orders o)
	{
        o.addPaymentDetails(p);
		p.setPayDate(new Date(System.currentTimeMillis()));
		sf.getCurrentSession().persist(p);
	}
	
	@Override
	public Orders getOrderById(int id) 
	{
		return sf.getCurrentSession().get(Orders.class, id);
	}
	
	@Override
	public Products getProductById(int id) 
	{
		return sf.getCurrentSession().get(Products.class, id);
	}

	@Override
	public void addOrderDetails(OrderDetails od, Orders o, Products p) 
	{
		od.setOrders(o);
		od.setProduct(p);
		sf.getCurrentSession().persist(od);
	}

	@Override
	public void addOrder(Orders o, int userId) {
		Users u = sf.getCurrentSession().get(Users.class, userId);
		u.addOrder(o);
		sf.getCurrentSession().saveOrUpdate(o);
	}

	

	@Override
	public Orders getOrder(int id) {
		return sf.getCurrentSession().get(Orders.class, id);
	}

	@Override
	public Orders order(int ordernumber) {
		String jpql = "select o from Orders o where o.orderNumber = :ordernumber";
		return sf.getCurrentSession().createQuery(jpql, Orders.class).setParameter("ordernumber", ordernumber)
				.getSingleResult();
	}



}
