package com.app.dao;

import java.util.List;

import com.app.pojos.*;


public interface IUserDao
{
     List<Categories> getAllCategories();
     Users performValidate(String email, String password);
     List<Categories> getAllProducts(int id);
     List<Products> productList();
     List<Products> selectiveProductList(int id);
     void addUser(Users u); 
     List<Orders> getAllUserOrders();
     List<OrderDetails>getOrderDetails(int id);
     List<Products> getProductsByName(String name);
     Users getUsersById(int id);
     void deleteUser(int id);
     Boolean setUserDetails(Users u);
	List<Orders> myOrders(Users u);
	void makePayment(Payment p, Orders o);
	Orders getOrderById(int id);
	Products getProductById(int id);
	void addOrderDetails(OrderDetails od, Orders o, Products p);
	void addOrder(Orders o, int userId);
	Orders getOrder(int id);
	Orders order(int ordernumber);

}
