package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.*;

@Repository
public class AdminDaoImpl implements IAdminDao {

	@Autowired
	private SessionFactory sf;
	
	@Override
	public List<Users> getAllUsers() 
	{		
		String jpql="select u from Users u";
		return sf.getCurrentSession().createQuery(jpql, Users.class).getResultList();
	}

	@Override
	public void addProduct(Products p, int id) throws Exception
	{
		String jpql = "select c from Categories c where c.id=:id";
		Categories c = sf.getCurrentSession().createQuery(jpql, Categories.class)
				         .setParameter("id", id).getSingleResult();
		c.addProduct(p);
		sf.getCurrentSession().saveOrUpdate(p);
		
	}

	@Override
	public Products removeProduct(int id)
	{
		Products p = sf.getCurrentSession().get(Products.class, id);
	    Categories t = p.getCategory();
		Categories c = sf.getCurrentSession().get(Categories.class, t.getId());
		c.removeProduct(p);
		sf.getCurrentSession().delete(p);
		return p;
	}
	
	@Override
	public List<OrderDetails> getAllOrders() 
	{
		String jpql="select od from OrderDetails od";
		return sf.getCurrentSession().createQuery(jpql, OrderDetails.class).getResultList();
	}
	
}
