import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-myorder',
  templateUrl: './myorder.component.html',
  styleUrls: ['./myorder.component.css']
})
export class MyorderComponent implements OnInit {

   orders:any
   user:any
   value:any
    
  constructor(private router:Router,
              private service:DataService) { }

  async ngOnInit() {

    this.user = JSON.parse(localStorage.getItem("user"))
    console.log(this.user)
    
    this.orders = await this.service.getUserOrders(this.user.user_id).toPromise()
    console.log(this.orders)

  }

  list(id)
  {
    console.log(id)
    this.value = id;
    localStorage.setItem("id", this.value.toString())
    console.log(localStorage.getItem("id"))
    this.router.navigate(['/odetails'])
  }

}
