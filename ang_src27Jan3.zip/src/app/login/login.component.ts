import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
//import { UserService } from '../user.service';
import { toUnicode } from 'punycode';
import { AuthService } from '../auth.service';
//import { EmitterserviceService } from '../emitterservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  
  constructor(private authService:AuthService, private router: Router) { }

  
  userDetails = {email:"", password:""};
  
   Check()
   {
    this.authService.CheckCredentialsWithDB(this.userDetails);
      
   }

  ngOnInit() {
  }
    

     


  
}