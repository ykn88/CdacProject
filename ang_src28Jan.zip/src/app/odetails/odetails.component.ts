import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-odetails',
  templateUrl: './odetails.component.html',
  styleUrls: ['./odetails.component.css']
})
export class OdetailsComponent implements OnInit {

  id:Number
  values:any

  constructor(private router: Router, 
              private service: DataService) { }

  async ngOnInit() 
  {
     
     this.id = parseInt(localStorage.getItem('id'))
     console.log(this.id)
 
     this.values = await this.service.getOrderDetails(this.id).toPromise()

     console.log(this.values)
      

  }

}
