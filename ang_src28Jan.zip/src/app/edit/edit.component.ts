import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  user:any

  constructor(private router:Router, private service:DataService) { }

  ngOnInit()
  {
     this.user = JSON.parse(localStorage.getItem('user'))
     console.log(this.user)

  }

  update()
  {
    console.log(this.user)
    this.service.getMyProfile(this.user).subscribe((result)=>{
      console.log("Update Successful")
      alert("Details Updated")
    })

    this.router.navigate(['/home'])
  }

}
