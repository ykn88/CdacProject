import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';
//import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-listusers',
  templateUrl: './listusers.component.html',
  styleUrls: ['./listusers.component.css']
})
export class ListusersComponent implements OnInit {

  userlist :any;
  no=0;
  constructor(private router:Router, private service:DataService) { 
    
  }

  ngOnInit() {
   let test = this.service.listUser()
   test.subscribe((result)=>{
     console.log(result)
     this.userlist = result
   })
  }

  

  onDelete(no : Number){
       console.log(no);
       this.service.deleteUser(no).subscribe((res)=>{
        console.log(res);
       });
  }
}
