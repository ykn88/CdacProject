import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
//import { UserService } from '../user.service';
import { toUnicode } from 'punycode';
import { AuthService } from '../auth.service';
//import { EmitterserviceService } from '../emitterservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  
  constructor(private authService:AuthService, private router: Router) { }

  
  userDetails = {email:"", password:""};
  message:any
  
   Check()
   {
      if(this.userDetails.email.length == 0)
        alert("Enter email")
      else if(this.userDetails.password.length == 0)
        alert("Enter password")  
      else
      {  
        this.authService.CheckCredentialsWithDB(this.userDetails);

        if(sessionStorage.getItem('login_status') != '1')
          this.message = "Invalid email and password"
      }    
   }

  ngOnInit() {
  }
    

     


  
}