import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms'


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user =
  {
    "fname" : '',
    "lname" : '',
    "email" :'',
    "password" : '',
    "address":'',
    "phone" : '',
    "type" : ''
  }

  constructor(
    private router: Router,private service:DataService
    ) { }

   

  ngOnInit() {

   


  }

  onSignup(formData) {

    console.log(formData.form.value);
    this.user={
      "fname":formData.form.value.fname,
      "lname":formData.form.value.lname,
      "email":formData.form.value.email,
      "password":formData.form.value.password,
      "address":formData.form.value.address,
      "phone":formData.form.value.phone,
      "type" : "CUSTOMER"
    }

   

    this.service.addUser(this.user).subscribe((result)=>{
      console.log(result);
      this.router.navigate(['/home']); 
      alert(' Registration Successful');

    })

    
  }


  
  onCancel() {
    this.router.navigate(['']);
    
  }
}