import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-newproduct',
  templateUrl: './newproduct.component.html',
  styleUrls: ['./newproduct.component.css']
})
export class NewproductComponent implements OnInit {

  product =
  {
    "prodName" : '',
    "prodDesc" : '',
    "prodQuantity" :'',
    "price" : '',
    "prodImage":''
  }

  image:any
  category_id:any
  constructor(
    private router: Router,private service:DataService) { }

  ngOnInit() {
  }

  onSignup(formData) {
    console.log(formData.form.value);
    this.product={
      "prodName":formData.form.value.prodName,
      "prodDesc":formData.form.value.prodDesc,
      "prodQuantity":formData.form.value.prodQuantity,
      "price":formData.form.value.price,
      "prodImage":formData.form.value.prodImage
    }
    //this.image = formData.form.value.image
    console.log(this.product.prodImage)
    this.category_id = formData.form.value.category_id
    console.log(this.category_id)
    this.product.prodImage = this.image
    this.service.addProduct(this.category_id,this.product).subscribe((result)=>{
      console.log(result);
      alert(' Product Added Successfully');

      this.router.navigate(['/admin']); 
    })

    }

    onSelectFile(event)
    {
      this.image=event.target.files[0];
      
    }

    
  
  
  onCancel() {
    this.router.navigate(['']);
    
  }
}