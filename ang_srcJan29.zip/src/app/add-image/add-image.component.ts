import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-image',
  templateUrl: './add-image.component.html',
  styleUrls: ['./add-image.component.css']
})
export class AddImageComponent implements OnInit {

  constructor(private service:DataService, private router:Router) { }

  product:any
  id:any
  image:any;

  ngOnInit() {
   

  }

  async click()
  {
       this.product = await this.service.getProductById(this.id).toPromise()
       console.log(this.product)
  }

  onSelectFile(event)
  {
    this.image=event.target.files[0];
    
  }

  upload()
  {
    
  }

}
