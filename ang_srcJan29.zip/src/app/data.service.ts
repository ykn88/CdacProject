import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(public http:HttpClient) { }

  validateUser(userDetails)
  {
    return this.http.post("http://localhost:8080/testProject/user/login", userDetails);
  }

  getAllCategories()
  {
    return this.http.get("http://localhost:8080/testProject/user/lc");
  }

  getAllProducts()
  {
    return this.http.get("http://localhost:8080/testProject/user/prod");
  }

  getCatProducts(id)
  {
      return this.http.get("http://localhost:8080/testProject/user/sprod/"+ id)
  }

  addUser(user)
  {
    return this.http.post("http://localhost:8080/testProject/user/adduser", user);
  }
 
  listUser()
  {
    return this.http.get("http://localhost:8080/testProject/admin/allusers");
  }

  deleteUser(user_id)
  {
    return this.http.delete("http://localhost:8080/testProject/admin/userDelete/"+ user_id);
  }

  addProduct(id, prod)
  {

     const form = new FormData();
     form.append("prodName",prod.prodName)
     form.append("prodDesc",prod.prodDesc)
     form.append("prodQuantity",prod.prodQuantity);
     form.append("price",prod.price)
     form.append("prodImage", prod.prodImage);

    return this.http.post("http://localhost:8080/testProject/admin/addproduct/"+ id, form);
  }

  addOrder(user_id, o)
  {
    return this.http.post("http://localhost:8080/testProject/user/addOrder/"+ user_id, o);
  }

  makePayment(p, order_id)
  {
    return this.http.post("http://localhost:8080/testProject/user/makepayment/"+ order_id, p);
  }

  order(orderNumber)
  {
    return this.http.post("http://localhost:8080/testProject/user/check", orderNumber);
  }
  
  addOrderDetails(oid, pid, detail)
  {
    return this.http.post("http://localhost:8080/testProject/user/addorderdetails/"+oid+"/"+pid, detail);
  }

  getUserOrders(user_id)
  {
    return this.http.get("http://localhost:8080/testProject/user/orders/"+ user_id);
  }

  getOrderDetails(id)
  {
    return this.http.get("http://localhost:8080/testProject/user/orderDetails/"+ id)
  }

  getMyProfile(c)
  {
    return this.http.post("http://localhost:8080/testProject/user/updateprofile", c)
  }

  getProductById(id)
  {
    return this.http.get("http://localhost:8080/testProject/user/id/" +id);
  }
  
}