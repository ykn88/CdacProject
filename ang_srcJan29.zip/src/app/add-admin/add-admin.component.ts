import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.css']
})
export class AddAdminComponent implements OnInit {

  user =
  {
    "fname" : '',
    "lname" : '',
    "email" :'',
    "password" : '',
    "address":'',
    "phone" : '',
    "type" : ''
  }

  constructor(
    private router: Router,private service:DataService
  ) { }

  ngOnInit() {
  }

  onSignup(formData) {
    console.log(formData.form.value);
    this.user={
      "fname":formData.form.value.fname,
      "lname":formData.form.value.lname,
      "email":formData.form.value.email,
      "password":formData.form.value.password,
      "address":formData.form.value.address,
      "phone":formData.form.value.phone,
      "type" : "ADMIN"
    }
    this.service.addUser(this.user).subscribe((result)=>{
      console.log(result);
      this.router.navigate(['/admin']); 
      alert(' Admin Registration Successful');

    })

    
  }
  
  onCancel() {
    this.router.navigate(['/admin']);
    
  }
}