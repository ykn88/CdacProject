package com.app.controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Categories;
import com.app.pojos.*;
import com.app.pojos.Products;
import com.app.pojos.Users;
import com.app.service.IUserService;

@RestController
@RequestMapping("/user")
@CrossOrigin
public class UserController
{
    @Autowired
	private IUserService service;
    
    @PostConstruct
    public void init()
    {
    	System.out.println("in init "+service);
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> validateUser(@RequestBody Users u)
    {
    	System.out.println("hello from login");
    	try {
         Users user = service.performValidate(u.getEmail(), u.getPassword());
         return new ResponseEntity<Users>(user, HttpStatus.OK);
    	}
    	catch (Exception e) {
       	 return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		}
    }
    
    @GetMapping("/lc")
    public ResponseEntity<?> listCategory()
    {
    			System.out.println("in list Category");
    			List<Categories> allCategories = service.getAllCategories();
    			if(allCategories.size() == 0)
    				return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    			return new ResponseEntity<List<Categories>>(allCategories, HttpStatus.OK);
    }
    
    @PostMapping("/prod")
    public ResponseEntity<?> listProduct(@RequestBody Categories c)
    {
    			System.out.println("in list Category");
    			List<Categories> allCategories = service.getAllProducts(c.getId());
    			if(allCategories.size() == 0)
    				return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    			return new ResponseEntity<List<Categories>>(allCategories, HttpStatus.OK);
    }
    
    @GetMapping("/prod")
    public ResponseEntity<?> productList()
    {
    	return new ResponseEntity<List<Products>>(service.productList(), HttpStatus.OK);
    }
    
    @GetMapping("/sprod/{category_id}")
    public ResponseEntity<?> selectiveListProduct(@PathVariable int category_id)
    {
    			System.out.println("in list Category");
    			List<Products> allCategories = service.selectiveProductList(category_id);
    			if(allCategories.size() == 0)
    				return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    			return new ResponseEntity<List<Products>>(allCategories, HttpStatus.OK);
    }
    
    @PostMapping("/adduser")
    public ResponseEntity<?> addUser(@RequestBody Users user)
    {
    	System.out.println("hello");
    	service.addUser(user);
    	return new ResponseEntity<Void>(HttpStatus.OK);
    }	   	
    
    @GetMapping("/orders")
    public ResponseEntity<?> orderList()
    {
    	return new ResponseEntity<List<Orders>>(service.getAllUserOrders(), HttpStatus.OK);
    }
    
    @GetMapping("/orderDetails/{id}")
    public ResponseEntity<?> orderDetailsList(@PathVariable int id)
    {
    	return new ResponseEntity<List<OrderDetails>>(service.getOrderDetails(id), HttpStatus.OK);
    }
    
    @GetMapping("/prods/{name}")
    public ResponseEntity<?> productsByName(@PathVariable String name)
    {  
    	try
    	{
    	return new ResponseEntity<List<Products>>(service.getProductsByName(name), HttpStatus.OK);
        }
    	catch(Exception e){
    		e.printStackTrace();
    		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    	}
    
    }
    
    @GetMapping("/myprofile/{id}")
	public ResponseEntity<?> getMyProfile(@PathVariable int id) {
		
		Users user = service.getUsersById(id);
		if (user == null)
			return new ResponseEntity<String>("User Not Found", HttpStatus.NO_CONTENT);
		return new ResponseEntity<Users>(user, HttpStatus.OK);
	}
    
    @PostMapping("/updateprofile")
	public ResponseEntity<?> getMyProfile(@RequestBody Users c) {
		if (service.setUserDetails(c))
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<String>("Update Failed", HttpStatus.NOT_ACCEPTABLE);
	}
    
    @GetMapping("/orders/{id}")
	public ResponseEntity<?> myOrders(@PathVariable int id)
	{
		Users u =service.getUsersById(id);
		List<Orders> userorders =service.myOrders(u);
		if(userorders.size()==0)
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<Orders>>(userorders,HttpStatus.OK);
	}
    
    @PostMapping("/makepayment/{order_id}")
	public ResponseEntity<?> makePayment(@RequestBody Payment p, @PathVariable int order_id)
	{
		System.out.println(p);
		try
		{
			Orders o =service.getOrderById(order_id);
			service.makePayment(p,o);
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			return new ResponseEntity<String>("Payment Failed", HttpStatus.NOT_ACCEPTABLE);
		}
	}
    
    @PostMapping("/addorderdetails/{oid}/{pid}")
	public ResponseEntity<?> addOrderDetails(@RequestBody OrderDetails od, @PathVariable int oid,@PathVariable int pid)
	{
		System.out.println(od);
		try 
		{
			Orders o =service.getOrderById(oid);
			System.out.println(o);
			Products p =service.getProductById(pid);
			System.out.println(p);
			service.addOrderDetails(od, o, p);
			return new ResponseEntity<Void>(HttpStatus.OK);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return new ResponseEntity<String>("Error Occured", HttpStatus.NOT_ACCEPTABLE);
		}
		
		
	}
   
    @PostMapping("/addOrder/{userId}")
   public ResponseEntity<?> addOrder(@PathVariable int userId, @RequestBody Orders o)
   {
	   try {
	        service.addOrders(o, userId);
	        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	   }
	   catch (Exception e) {
         e.printStackTrace();
         return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	   }
   }
    
  
    @GetMapping("/order/{order_id}")
    public ResponseEntity<?> order(@PathVariable int order_id)
    {
    	Orders o = service.getOrder(order_id);
    	return new ResponseEntity<Orders>(o, HttpStatus.OK);

    }
    
    @PostMapping("/check")
    public ResponseEntity<?> getOrderByOrderNumber(@RequestBody Orders o)
    {
    	try {
    	Orders od = service.order(o.getOrderNumber());
    	return new ResponseEntity<Orders>(od, HttpStatus.OK);
    	}
    	catch (Exception e) {
		    e.printStackTrace();
	    	return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);

    	}
    }
     @GetMapping("/id/{id}")
     public ResponseEntity<?> getProductById(@PathVariable int id)
     {
    	 return new ResponseEntity<Products>(service.getProductById(id), HttpStatus.OK);
     }
    
 
 
    
}
