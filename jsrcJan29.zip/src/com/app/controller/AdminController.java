package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.app.pojos.OrderDetails;
import com.app.pojos.Products;
import com.app.pojos.Users;
import com.app.service.IAdminService;
import com.app.service.IUserService;

@RestController
@CrossOrigin
@RequestMapping("/admin")
public class AdminController 
{
	@Autowired
	private IAdminService dao;
	
	@Autowired
	private IUserService custdao;
	
	
	@GetMapping("/allusers")
	public ResponseEntity<?> getAllCustomers()
	{
		System.out.println("In Users List");
		try 
		{
			List<Users> allUsers = dao.getAllUsers();
			return new ResponseEntity<List<Users>>(allUsers,HttpStatus.OK);					
		}
		catch (Exception e)
		{
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		}		
	}	
	@PostMapping
	public ResponseEntity<?> addUser(@RequestBody Users u)
	{		
		try {
			custdao.addUser(u);
			return new ResponseEntity<String>("User Added", HttpStatus.OK);
		} catch (Exception e) 
		{
					e.printStackTrace();
					return new ResponseEntity<String>("User Not Added", HttpStatus.NOT_ACCEPTABLE);
		}
	}
	
	@DeleteMapping("/userDelete/{user_id}")
	public ResponseEntity<?> deleteUser(@PathVariable int user_id)
	{
	    custdao.deleteUser(user_id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
//	@PostMapping("/addproduct/{id}")
//	public ResponseEntity<?> addProduct(@RequestBody Products cp, @PathVariable int id, @RequestParam(value = "prodImage", required = false) MultipartFile prodImage)
//	{		
//		
//		  try 
//		  { 
//			   if(prodImage!=null)
//			   {
//				   cp.setProdImage(prodImage.getBytes());
//			   }
//			    dao.addProduct(cp, id);
//			  return new ResponseEntity<Void>(HttpStatus.OK);
//		  } 
//		  catch (Exception e)
//		  {
//			  e.printStackTrace();
//		      return new ResponseEntity<Void>(HttpStatus.OK);
//		  }
//		 
//	}
	
	@PostMapping("/addproduct/{id}")
	public ResponseEntity<?> addProduct(@PathVariable int id, @RequestParam String prodName, @RequestParam String prodDesc,
			@RequestParam int prodQuantity, @RequestParam float price,@RequestParam(value = "prodImage", required = true) MultipartFile prodImage)
	{		
		
		  try 
		   {   
			  Products cp = new Products(prodName, prodDesc, prodQuantity, price);
			   if(prodImage!=null)
			   {
				   cp.setProdImage(prodImage.getBytes());
			   }
			    dao.addProduct(cp, id);
			  return new ResponseEntity<Void>(HttpStatus.OK);
		  } 
		  catch (Exception e)
		  {
			  e.printStackTrace();
		      return new ResponseEntity<Void>(HttpStatus.OK);
		  }
		 
	}
	
	@DeleteMapping("/delete/{prodId}")
	public ResponseEntity<?> deleteProduct(@PathVariable int prodId)
	{
		Products product = dao.removeProduct(prodId);
		return new ResponseEntity<Products>(product,HttpStatus.OK);
	}
	
	@GetMapping("/allorders")
	public ResponseEntity<?> getAllOrders()
	{
		System.out.println("In Orders List");
		try 
		{
			List<OrderDetails> allOrders = dao.getAllOrders();
			return new ResponseEntity<List<OrderDetails>>(allOrders,HttpStatus.OK);					
		}
		catch (Exception e)
		{
			return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
		}		
	}
	
}