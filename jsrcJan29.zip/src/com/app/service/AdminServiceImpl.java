package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

import com.app.dao.IAdminDao;
import com.app.pojos.*;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService {

	@Autowired
	private IAdminDao dao;
	
	@Override
	public List<Users> getAllUsers() {
		return dao.getAllUsers();
	}

	@Override
	public void addProduct(Products p, int id) throws Exception {
		dao.addProduct(p, id);
		
	}

	@Override
	public Products removeProduct(int id) {
		
		return dao.removeProduct(id);
	}

	@Override
	public List<OrderDetails> getAllOrders() {
		// TODO Auto-generated method stub
		return dao.getAllOrders();
	}

}
