package com.app.convenience;

import java.util.Date;

import com.app.pojos.payType;

public class God 
{
	private String address;
	private Date shippedDate;
	private Date orderDate;
    private int quantity;
    private float amount;
	private Date payDate;
	private payType type;
	private String prodName;
	
	
	
	public God(String address, Date shippedDate, Date orderDate, int quantity, float amount, Date payDate, payType type,
			String prodName) {
		super();
		this.address = address;
		this.shippedDate = shippedDate;
		this.orderDate = orderDate;
		this.quantity = quantity;
		this.amount = amount;
		this.payDate = payDate;
		this.type = type;
		this.prodName = prodName;
	}
	
	
	
	public String getProdName() {
		return prodName;
	}



	public void setProdName(String prodName) {
		this.prodName = prodName;
	}



	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Date getShippedDate() {
		return shippedDate;
	}
	public void setShippedDate(Date shippedDate) {
		this.shippedDate = shippedDate;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public Date getPayDate() {
		return payDate;
	}
	public void setPayDate(Date payDate) {
		this.payDate = payDate;
	}
	public payType getType() {
		return type;
	}
	public void setType(payType type) {
		this.type = type;
	}

	

}
