package com.app.pojos;

public enum userTypes {
	
	CUSTOMER, ADMIN

}
