package com.app.pojos;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "order_details")
public class OrderDetails
{
   private Integer orderDetailsId;
   private int quantity;
 
   private Orders orders;
   private Products product;
   
   
   public OrderDetails() {
	// TODO Auto-generated constructor stub
}

public OrderDetails(int quantity, float totalPrice) {
	super();
	this.quantity = quantity;
	
}

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
public Integer getOrderDetailsId() {
	return orderDetailsId;
}

public void setOrderDetailsId(Integer orderDetailsId) {
	this.orderDetailsId = orderDetailsId;
}

@Column(name = "product_quantity")
public int getQuantity() {
	return quantity;
}

public void setQuantity(int quantity) {
	this.quantity = quantity;
}




@ManyToOne
@JsonIgnore
@JoinColumn(name = "order_id")
public Orders getOrders() {
	return orders;
}

public void setOrders(Orders orders) {
	this.orders = orders;
}



@OneToOne
@JoinColumn(name = "product_id")
public Products getProduct() {
	return product;
}

public void setProduct(Products product) {
	this.product = product;
}

@Override
public String toString() {
	return "OrderDetails [orderDetailsId=" + orderDetailsId + ", quantity=" + quantity + "]";
}
   
   
	
}
