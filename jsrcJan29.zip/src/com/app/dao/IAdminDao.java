package com.app.dao;

import java.util.List;

import com.app.pojos.*;

public interface IAdminDao {
 
	List<Users> getAllUsers();
	void addProduct(Products p, int id) throws Exception;
	Products removeProduct(int id);
	List<OrderDetails> getAllOrders();
	
}
