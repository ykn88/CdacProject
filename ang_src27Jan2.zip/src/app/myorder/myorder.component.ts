import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-myorder',
  templateUrl: './myorder.component.html',
  styleUrls: ['./myorder.component.css']
})
export class MyorderComponent implements OnInit {

   orders:any
   user:any
    
  constructor(private router:Router,
              private service:DataService) { }

  async ngOnInit() {

    this.user = JSON.parse(localStorage.getItem("user"))
    console.log(this.user)
    
    this.orders = await this.service.getUserOrders(this.user.user_id).toPromise()
    console.log(this.orders)

  }

}
