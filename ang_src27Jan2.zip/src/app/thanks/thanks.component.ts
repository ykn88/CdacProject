import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thanks',
  templateUrl: './thanks.component.html',
  styleUrls: ['./thanks.component.css']
})
export class ThanksComponent implements OnInit {

  constructor() { }
  today:any

  ngOnInit()
  {
     this.today = new Date();
       var dd = String(this.today.getDate()).padStart(2, '0');
       var mm = String(this.today.getMonth() + 1).padStart(2, '0'); //January is 0!
         var yyyy = this.today.getFullYear();

           this.today = mm + '/' + dd + '/' + yyyy;
           console.log(this.today)

  }

}
